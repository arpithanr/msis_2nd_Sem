package inheritance.example;

import java.util.*;

/**
 * 
 */
public class DVD2 extends InventoryItem {

    /**
     * Default constructor
     */
    public DVD2() {
    }

    public DVD2(double price,String manufacturer) {
    	super(price);
    	this.manufacturer = manufacturer;
        // TODO implement here
    }
    /**
     * 
     */
    private String manufacturer;

    /**
     * @return
     */
    public String getManufacturer() {
        // TODO implement here
        return manufacturer;
    }

    /**
     * @param manufacturer 
     * @return
     */
    public void setManufacturer(String manufacturer) {
        // TODO implement here
    }

    /**
     * @param manufacturer
     */
   

}