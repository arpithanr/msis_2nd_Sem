package inheritance.example;

public class TestInventory {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book b1 = new Book(2000, "xyz");
		assert(b1.getPrice() == 2000);
		b1.setPrice(5000);
		assert(b1.getPrice() == 3000);
		
		DVD2 d1 = new DVD2(3000, "abc");
	}

}
