package inheritance.example;

import java.util.*;

/**
 * 
 */
public class InventoryItem {

    /**
     * Default constructor
     */
    public InventoryItem() {
    }
    
    public InventoryItem(double price) {
        // TODO implement here
    	this.price = price;
    }

    /**
     * 
     */
    private double price;

    /**
     * @return
     */
    public double getPrice() {
        // TODO implement here
        return price;
    }

    /**
     * @param price 
     * @return
     */
    public void setPrice(double price) {
        // TODO implement here
    	this.price = price;
    }

    /**
     * @param price
     */
    

}