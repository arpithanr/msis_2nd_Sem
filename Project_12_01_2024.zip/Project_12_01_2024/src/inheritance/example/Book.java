package inheritance.example;

import java.util.*;

/**
 * 
 */
public class Book extends InventoryItem {

    /**
     * Default constructor
     */
    public Book() {
    }
    
    public Book(double price,String authorname) {
        // TODO implement here
    	super(price);
    	this.authorname = authorname;
    }

    /**
     * 
     */
    private String authorname;

    /**
     * @return
     */
    public String getAuthorname() {
        // TODO implement here
        return authorname;
    }

    /**
     * @param authorname 
     * @return
     */
    public void setAuthorname(String authorname) {
        // TODO implement here
    	this.authorname = authorname;
    }

    /**
     * @param authorname
     */
    

}