
import java.util.*;

/**
 * 
 */
public class Drug {

    /**
     * Default constructor
     */
    public Drug() {
    }

    /**
     * 
     */
    private int drug_id;

    /**
     * 
     */
    private String drug_name;

    /**
     * 
     */
    private int price;

    /**
     * 
     */
    private String manufacturer;

    /**
     * 
     */
    private int stock_position;

    /**
     * @param int drug_id 
     * @param String drug_name 
     * @param int price 
     * @param String manufacturer 
     * @param int stock_position 
     * @return
     */
    public void Drug(void int drug_id, void String drug_name, void int price, void String manufacturer, void int stock_position) {
        // TODO implement here
        return null;
    }

    /**
     * @param int drug_id 
     * @param String drug_name
     */
    public void Drug(void int drug_id, void String drug_name) {
        // TODO implement here
    }

    /**
     * @return
     */
    public int getDrug_id() {
        // TODO implement here
        return 0;
    }

    /**
     * @return
     */
    public String getDrug_name() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public int getPrice() {
        // TODO implement here
        return 0;
    }

    /**
     * @return
     */
    public String getManufacturer() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public int getStock_position() {
        // TODO implement here
        return 0;
    }

    /**
     * @param int drug_id 
     * @return
     */
    public void setDrug_id(void int drug_id) {
        // TODO implement here
        return null;
    }

    /**
     * @param String drug_name 
     * @return
     */
    public void setDrug_name(void String drug_name) {
        // TODO implement here
        return null;
    }

    /**
     * @param int price 
     * @return
     */
    public void setPrice(void int price) {
        // TODO implement here
        return null;
    }

    /**
     * @param String manufacturer 
     * @return
     */
    public void setManufacturer(void String manufacturer) {
        // TODO implement here
        return null;
    }

    /**
     * @param int stock_position 
     * @return
     */
    public void setStock_position(void int stock_position) {
        // TODO implement here
        return null;
    }

    /**
     * @param int drug_id 
     * @param String drug_name 
     * @return
     */
    public int searchById(void int drug_id, void String drug_name) {
        // TODO implement here
        return 0;
    }

    /**
     * @param int drug_id 
     * @return
     */
    public String isAvailable(void int drug_id) {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public void getDetailsOfDrug() {
        // TODO implement here
        return null;
    }

    /**
     * @param int drug_id 
     * @return
     */
    public int totalCost(void int drug_id) {
        // TODO implement here
        return 0;
    }

    /**
     * @return
     */
    public String toString() {
        // TODO implement here
        return "";
    }

}