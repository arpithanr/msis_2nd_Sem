package lab;

public interface ISoftware {
	String getSoftware();
}
