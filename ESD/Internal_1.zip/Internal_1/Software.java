package lab;

public class Software implements ISoftware {

	private String software_name;
	private String configuaration;
	
	
	public Software(String software_name, String configuaration) {
		super();
		this.software_name = software_name;
		this.configuaration = configuaration;
	}

	public String getSoftware_name() {
		return software_name;
	}

	public void setSoftware_name(String software_name) {
		this.software_name = software_name;
	}

	@Override
	public String getSoftware() {
		// TODO Auto-generated method stub
		return this.software_name;
	}

	public String getConfiguaration() {
		return configuaration;
	}

	public void setConfiguaration(String configuaration) {
		this.configuaration = configuaration;
	}

	@Override
	public String toString() {
		return "Software [software_name=" + software_name + ", configuaration=" + configuaration + "]";
	}

	

}
