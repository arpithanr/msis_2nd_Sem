
import java.util.*;

/**
 * 
 */
public class Clock {

    /**
     * Default constructor
     */
    public Clock() {
    }

    /**
     * 
     */
    private int hr;

    /**
     * 
     */
    private int min;

    /**
     * 
     */
    private int sec;

    /**
     * 
     */
    private String ampm;

    /**
     * @param hr 
     * @param min 
     * @param sec 
     * @param ampm
     */
    public void Clock(int hr, int min, int sec, String ampm) {
        // TODO implement here
    }

    /**
     * @return
     */
    public int getHr() {
        // TODO implement here
        return 0;
    }

    /**
     * @return
     */
    public int getMin() {
        // TODO implement here
        return 0;
    }

    /**
     * @return
     */
    public int getSec() {
        // TODO implement here
        return 0;
    }

    /**
     * @return
     */
    public String getAmPm() {
        // TODO implement here
        return "";
    }

    /**
     * @param hr 
     * @return
     */
    public void setHr(int hr) {
        // TODO implement here
        return null;
    }

    /**
     * @param min 
     * @return
     */
    public void setMin(int min) {
        // TODO implement here
        return null;
    }

    /**
     * @param sec 
     * @return
     */
    public void setSec(int sec) {
        // TODO implement here
        return null;
    }

    /**
     * @param ampm 
     * @return
     */
    public void setAmPm(String ampm) {
        // TODO implement here
        return null;
    }

    /**
     * @param c1 
     * @return
     */
    public static boolean isValid(Clock c1) {
        // TODO implement here
        return false;
    }

}