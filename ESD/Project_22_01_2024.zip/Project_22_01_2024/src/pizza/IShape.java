package pizza;

public interface IShape {
    double getArea();
}