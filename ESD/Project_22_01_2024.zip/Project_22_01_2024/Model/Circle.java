
import java.util.*;

/**
 * 
 */
public class Circle implements IShape, IShape {

    /**
     * Default constructor
     */
    public Circle() {
    }

    /**
     * 
     */
    private double radius;

    /**
     * @return
     */
    public double getArea() {
        // TODO implement here
        return 0.0d;
    }

    /**
     * @return
     */
    public double getArea() {
        // TODO implement here
        return 0.0d;
    }

    /**
     * @return
     */
    public double getArea() {
        // TODO implement here
        return 0.0d;
    }

}