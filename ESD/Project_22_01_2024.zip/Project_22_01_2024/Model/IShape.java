
import java.util.*;

/**
 * 
 */
public interface IShape {

    /**
     * @return
     */
    public double getArea();

}