
import java.util.*;

/**
 * 
 */
public class Pizza {

    /**
     * Default constructor
     */
    public Pizza() {
    }

    /**
     * 
     */
    private double price;

    /**
     * @return
     */
    public double getPrice() {
        // TODO implement here
        return 0.0d;
    }

    /**
     * @return
     */
    public IShape getShape() {
        // TODO implement here
        return null;
    }

    /**
     * @param price 
     * @param shape
     */
    public void Pizza(double price, IShape shape) {
        // TODO implement here
    }

}