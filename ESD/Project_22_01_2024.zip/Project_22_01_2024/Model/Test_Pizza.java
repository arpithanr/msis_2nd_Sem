
import java.util.*;

/**
 * 
 */
public class Test_Pizza {

    /**
     * Default constructor
     */
    public Test_Pizza() {
    }

}