
import java.util.*;

/**
 * 
 */
public class Rectangle implements IShape, IShape {

    /**
     * Default constructor
     */
    public Rectangle() {
    }

    /**
     * 
     */
    private double height;

    /**
     * 
     */
    private double width;

    /**
     * @return
     */
    public double getArea() {
        // TODO implement here
        return 0.0d;
    }

    /**
     * @return
     */
    public double getArea() {
        // TODO implement here
        return 0.0d;
    }

    /**
     * @return
     */
    public double getArea() {
        // TODO implement here
        return 0.0d;
    }

}