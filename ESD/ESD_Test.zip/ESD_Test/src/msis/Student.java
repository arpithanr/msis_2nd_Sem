package msis;

import java.util.ArrayList;
import java.util.List;

public class Student {
    private int ID;
    private String name;
    private List<WeeklyLabTask> enrolledTasks;

    public Student(int ID, String name) {
        this.ID = ID;
        this.name = name;
        this.enrolledTasks = new ArrayList<>();
    }

    
    public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public void EnrollLabTask(WeeklyLabTask task) {
        enrolledTasks.add(task);
        System.out.println("Student " + name + " enrolled in task: " + task.getDescription());
    }

    public void SubmitLabTask() {
        // Code to submit a lab task
        System.out.println("Student " + name + " submitted lab tasks.");
    }
}
