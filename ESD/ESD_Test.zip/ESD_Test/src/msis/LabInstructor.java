package msis;

public class LabInstructor {
    private int ID;
    private String name;

    public LabInstructor(int ID, String name) {
        this.ID = ID;
        this.name = name;
    }
    
    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void AssignTask(WeeklyLabTask task) {
        // Code to assign a task to students
        System.out.println("Task assigned by instructor " + name + ": " + task.getDescription());
    }

    public void InstallSoftware(PC pc, Software software) {
        // Code to install software on a PC
        System.out.println("Software " + software.getName() + " installed on PC " + pc.getID());
    }
}
