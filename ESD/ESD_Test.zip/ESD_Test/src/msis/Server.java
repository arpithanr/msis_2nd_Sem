package msis;

public class Server {
    private String ipAddress;
    private String status;

    public Server(String ipAddress, String status) {
        this.ipAddress = ipAddress;
        this.status = status;
    }
}
