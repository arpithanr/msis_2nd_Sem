package msis;

public enum SoftwareType {
    SYSTEM,
    APPLICATION
}