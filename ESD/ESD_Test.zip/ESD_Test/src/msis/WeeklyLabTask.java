package msis;

public class WeeklyLabTask {
    private int ID;
    private String description;
    private String deadline;

    public WeeklyLabTask(int ID, String description, String deadline) {
        this.ID = ID;
        this.description = description;
        this.deadline = deadline;
    }

    public String getDescription() {
        return description;
    }
}