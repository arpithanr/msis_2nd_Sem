package msis;

public class PC {
    private int ID;
    private String status;
    private String configuration;
    private Software software;

    public PC(int ID, String status, String configuration) {
        this.ID = ID;
        this.status = status;
        this.configuration = configuration;
    }

    public void InstallSoftware(Software software) {
        this.software = software;
        System.out.println("Software installed on PC " + ID + ": " + software.getName());
    }

    public int getID() {
        return ID;
    }

	public Software getSoftware() {
		return software;
	}

	public void setSoftware(Software software) {
		this.software = software;
	}
    
}
