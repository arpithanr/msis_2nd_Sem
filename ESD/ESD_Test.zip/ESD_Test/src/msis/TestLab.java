package msis;

public class TestLab {
    public static void main(String[] args) {
        // Creating instances of classes
        Student student1 = new Student(1, "Alice");
        Student student2 = new Student(2, "Bob");
        LabInstructor instructor = new LabInstructor(101, "Dr. Smith");
        WeeklyLabTask labTask = new WeeklyLabTask(1, "Implement Binary Search", "2024-03-01");
        PC pc1 = new PC(1, "Available", "High-end");
        PC pc2 = new PC(2, "Available", "Low-end");
        Software systemSoftware = new Software("Windows 10", SoftwareType.SYSTEM);
        Software applicationSoftware = new Software("Eclipse IDE", SoftwareType.APPLICATION);

        // Test case 1: Enroll lab task for students
        student1.EnrollLabTask(labTask);
        student2.EnrollLabTask(labTask);

        // Test case 2: Assign task by instructor
        instructor.AssignTask(labTask);

        // Test case 3: Install software on PC
        pc1.InstallSoftware(systemSoftware);
        pc2.InstallSoftware(applicationSoftware);

        // Test case 4: Validate current object values
        assert student1.getName().equals("Alice") : "Test case failed: Student name mismatch.";
        assert instructor.getName().equals("Dr. Smith") : "Test case failed: Instructor name mismatch.";
        assert labTask.getDescription().equals("Implement Binary Search") : "Test case failed: Lab task description mismatch.";
        assert pc1.getID() == 1 : "Test case failed: PC ID mismatch.";
        assert pc2.getID() == 2 : "Test case failed: PC ID mismatch.";
        assert pc1.getSoftware().equals(systemSoftware) : "Test case failed: Software installation mismatch.";
        assert pc2.getSoftware().equals(applicationSoftware) : "Test case failed: Software installation mismatch.";

        // Test case 5: Validate PC's application software after installing different software
        Software newApplicationSoftware = new Software("Visual Studio Code", SoftwareType.APPLICATION);
        pc2.InstallSoftware(newApplicationSoftware);
        assert pc2.getSoftware().equals(newApplicationSoftware) : "Test case failed: Software installation mismatch.";
        
        System.out.println("All test cases passed successfully!");
    }
}
