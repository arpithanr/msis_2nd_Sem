package msis;

public class Software {
    private String name;
    private SoftwareType type;

    public Software(String name, SoftwareType type) {
        this.name = name;
        this.type = type;
    }

    public String getName() {
        return name;
    }
}
