
import java.util.*;

/**
 * 
 */
public class RowThread extends Thread {

    /**
     * Default constructor
     */
    public RowThread() {
    }

    /**
     * 
     */
    private int rowSum = 0;

    /**
     * 
     */
    private int row = 0;

    /**
     * 
     */
    private int arr;

    /**
     * @param arr 
     * @param r
     */
    void RowThread(int arr, int r) {
        // TODO implement here
    }

    /**
     * @return
     */
    public void run() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void calculateSum() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public int getRowSum() {
        // TODO implement here
        return 0;
    }

}