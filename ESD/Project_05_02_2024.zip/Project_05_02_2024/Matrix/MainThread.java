
import java.util.*;

/**
 * 
 */
public class MainThread {

    /**
     * Default constructor
     */
    public MainThread() {
    }

    /**
     * @param args 
     * @return
     */
    public void main(Set<String> args) {
        // TODO implement here
        return null;
    }

    /**
     * @param arr 
     * @return
     */
    private void printMatrix(Set<int> arr) {
        // TODO implement here
        return null;
    }

    /**
     * @param arr 
     * @param r 
     * @return
     */
    public void populateMatrix(int arr, void r) {
        // TODO implement here
        return null;
    }

    /**
     * @param arr 
     * @return
     */
    public int printSum(int arr) {
        // TODO implement here
        return 0;
    }

}