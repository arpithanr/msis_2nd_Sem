package com.msis;

public class MainThread {

	public static void main(String[] args) {
		
		String[] inputs = {"Manipal", "Welcomes", "you"};

        Thread[] threads = new Thread[inputs.length];
        for (int i = 0; i < inputs.length; i++) {
            ThreadClass thread = new ThreadClass(inputs[i]);
            threads[i] = thread;
            thread.start();
        }
        try {
            for (Thread thread : threads) {
                thread.join();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Main thread exiting in the last.");
	}
}
