package com.msis;

public class ThreadClass extends Thread{
	
	private String input;
	
	ThreadClass(String input){
		this.input = input;
	}
	
	 private String sortString(String str) {
	        char[] chars = str.toCharArray();
	        java.util.Arrays.sort(chars);
	        return new String(chars);
	    }

	 private String reverseString(String str) {
	        return new StringBuilder(str).reverse().toString();
	 }
	 
	 @Override
	 public void run()
	 {
		 String sortedString = sortString(input);
		 String reversedString = reverseString(input);
		 String uppercaseString = input.toUpperCase();
		 
		 System.out.println("The sorted string is " + sortedString);
		 System.out.println("The reversed string is " + reversedString );
		 System.out.println("The converted string is " + uppercaseString);
		 
	 }
}
