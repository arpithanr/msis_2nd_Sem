/**
 * 
 */
/**
 * @author MSIS
 *
 */
module Lab_internal_2 {
}