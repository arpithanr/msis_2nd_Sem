package thread;

class CallMe {
	
	public void call(String msg)
	{
		System.out.print("[" + msg);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		System.out.println("]");
	}
	
}
class Caller implements Runnable{
	
	CallMe target;
	String msg;
	Thread t;
	
	public Caller(CallMe target, String msg) {
		// TODO Auto-generated constructor stub
		this.target = target;
		this.msg = msg;
		t = new Thread(this);
		t.start();
	}

	@Override
	public  void run() {
		// TODO Auto-generated method stub
		synchronized (target) {
			target.call(msg);
		}	
	}
	
}

public class SyncDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CallMe target = new CallMe();
		Caller p1 = new Caller(target, "Hello");
		Caller p2 = new Caller(target, "Synchronized");
		Caller p3 = new Caller(target, "World");
		
	}

}
