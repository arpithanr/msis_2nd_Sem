package thread;

public class ThreadTest1 {

	ThreadEx1 t1, t2;
	
	public void beginTest() {
		t1 = new ThreadEx1("One", 4);
		t2 = new ThreadEx1("Two", 6);
		System.out.println("Threads are created....");
		t1.start();
		t2.start();
		System.out.println("Threads are ready....");
		System.out.println("t1 status: " + t1.isAlive());
		System.out.println("t2 status: " + t2.isAlive());
		
		try {
			t1.join();
			t2.join();
		}catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		
		System.out.println("t1 status: " + t1.isAlive());
		System.out.println("t2 status: " + t2.isAlive());
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ThreadTest1 obj = new ThreadTest1();
		obj.beginTest();
		
		System.out.println("Main thread exit....");
	}

}
