package thread;

public class ThreadEx1 extends Thread {
	
	private int num;
	
	public ThreadEx1(String threadname, int num) {
		// TODO Auto-generated constructor stub
		super(threadname);
		this.num = num;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
		
		for (int i = 0; i < num; i++) {
			System.out.println(getName() + " : " + i);
			work();
		}
	}
	
	public void work() {
		
		/*
		 * long t1 = System.currentTimeMillis()+500;
		 * while(t1>System.currentTimeMillis());
		 */
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}





