package com.msis;
import java.util.*;

/**
 * 
 */
public interface Stack {

    /**
     * @param int data 
     * @return
     */
    public void push( int data);

    /**
     * @return
     */
    public int pop();

}