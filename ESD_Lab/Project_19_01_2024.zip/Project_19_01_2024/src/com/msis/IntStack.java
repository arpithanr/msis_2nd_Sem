package com.msis;
import java.util.*;

/**
 * 
 */
public class IntStack implements Stack {

    /**
     * Default constructor
     */
    public IntStack() {
    }

    /**
     * @param int data 
     * @return
     */
    public void push(int data) {
        // TODO implement here
    }

    /**
     * @return
     */
    public int pop() {
        // TODO implement here
        return 0;
    }

}