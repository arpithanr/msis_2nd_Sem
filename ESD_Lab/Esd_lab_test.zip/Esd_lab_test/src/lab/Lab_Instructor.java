package lab;

public class Lab_Instructor {

	private String instructor_name;
	private String server;
	private Software software;
	
	public Lab_Instructor(String instructor_name, String server, Software software) {
		super();
		this.instructor_name = instructor_name;
		this.server = server;
		this.software = software;
	}

	public String getInstructor_name() {
		return instructor_name;
	}

	public void setInstructor_name(String instructor_name) {
		this.instructor_name = instructor_name;
	}

	public String getServer() {
		return server;
	}

	public void setServer(String server) {
		this.server = server;
	}

	public Software getSoftware() {
		return software;
	}

	public void setSoftware(Software software) {
		this.software = software;
	}

	@Override
	public String toString() {
		return "Lab_Instructor [instructor_name=" + instructor_name + ", server=" + server + ", software=" + software
				+ ", toString()=" + super.toString() + "]";
	}	
}
