package lab;

import java.util.List;
import java.util.*;

public class Lab{
	private String lab_name;
	private List<Student> students;
	private Lab_Instructor instructor;
	
	public Lab(String lab_name, Lab_Instructor instructor) {
		super();
		this.lab_name = lab_name;
		this.students = new ArrayList<>();
		this.instructor = instructor;
	}
	
	public String getLab_name() {
		return lab_name;
	}

	public void setLab_name(String lab_name) {
		this.lab_name = lab_name;
	}



	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}

	public Lab_Instructor getInstructor() {
		return instructor;
	}

	public void setInstructor(Lab_Instructor instructor) {
		this.instructor = instructor;
	}
	
	public void addStudents(Student student) {
		this.students.add(student);
	}

}
