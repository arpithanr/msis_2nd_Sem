package lab;

public class Student {
	
	private int id;
	private String name;
	private String department_name;
	private String lab_tasks;
	
	public Student(int id, String name, String department_name, String lab_tasks) {
		super();
		this.id = id;
		this.name = name;
		this.department_name = department_name;
		this.lab_tasks = lab_tasks;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment_name() {
		return department_name;
	}
	public void setDepartment_name(String department_name) {
		this.department_name = department_name;
	}
	public String getLab_tasks() {
		return lab_tasks;
	}
	public void setLab_tasks(String lab_tasks) {
		this.lab_tasks = lab_tasks;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", department_name=" + department_name + ", lab_tasks="
				+ lab_tasks + "]";
	}
}
