package lab;

public class TestLab {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Software software_1 = new Software("Application Software","Configured by file1");
		Software software_2 = new Software("System Software","Configured by file2");
		
		Lab_Instructor instructor_1 =  new Lab_Instructor("Praveen","123.11.23.192", software_1);
		Lab_Instructor instructor_2 =  new Lab_Instructor("Nivin","123.11.23.193", software_2);

		Student student_1 = new Student(231039001,"Nithin","Embedded System", "Perform task1");
		Student student_2 = new Student(231039002,"Nikhil","Cyber Security", "Perform task2");
		Student student_3 = new Student(231039003,"Manohar","MVT", "Perform task3");
		
		Lab lab = new Lab("msis", instructor_1);
		lab.addStudents(student_1);
		lab.addStudents(student_2);
		lab.addStudents(student_3);
		
		assert(lab.getInstructor().getInstructor_name().equals("Praveen"));
		assert(lab.getInstructor().getServer().equals("123.11.23.192"));
		assert(lab.getInstructor().getSoftware().getSoftware_name().equals("Application Software"));
		assert(lab.getLab_name().equals("msis"));
		assert(lab.getStudents().size() == 3);
		assert(lab.getStudents().get(0).getName().equals("Nithin"));
		assert(lab.getStudents().get(0).getId() == 231039001);
		assert(lab.getStudents().get(0).getLab_tasks().equals("Perform task1"));
		
	}

}
