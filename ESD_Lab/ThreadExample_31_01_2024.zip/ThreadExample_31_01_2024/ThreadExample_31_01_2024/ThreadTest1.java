package javathreads;

public class ThreadTest1 {

	ThreadEx1 t1, t2;
	
	public void beginTest() {
		t1 = new ThreadEx1("One", 4);
		t2 = new ThreadEx1("Two", 6);
		System.out.println("Threads are created....");
		t1.start();
		t2.start();
		System.out.println("Threads are ready....");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ThreadTest1 obj = new ThreadTest1();
		obj.beginTest();
		
		System.out.println("Main thread exit....");
	}

}
