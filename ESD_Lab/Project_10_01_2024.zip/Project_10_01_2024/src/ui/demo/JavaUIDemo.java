package ui.demo;

import javax.swing.JFrame;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.*;

import javax.swing.JButton;

public class JavaUIDemo extends JFrame {
	
	public JavaUIDemo() {
	//	getContentPane().setLayout(new FlowLayout());
		
	//	ActionListener l = new ActionListener() {
		//	public void actionPerformed(ActionEvent e)
			{
				getContentPane().setBackground(Color.RED);
				
			}
	//	};
		
		JButton button =  new JButton("RED");
		//getContentPane().add(button);
		
		
		//setSize(500, 500);
		//setVisible(true);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new JavaUIDemo();
	}

}
