/**
 * 
 */
/**
 * @author MSIS
 *
 */
module Project_10_01_2024 {
	requires java.desktop;
}