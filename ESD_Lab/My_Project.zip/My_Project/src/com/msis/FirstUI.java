package com.msis;

import javax.swing.JFrame;

public class FirstUI extends JFrame {

	public FirstUI() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
