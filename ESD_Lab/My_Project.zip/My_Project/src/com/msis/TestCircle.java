package com.msis;

public class TestCircle {



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle C1= new Circle(new Point(20, 40), 100);
		C1.setRGB(125,25,50);
	}

}
