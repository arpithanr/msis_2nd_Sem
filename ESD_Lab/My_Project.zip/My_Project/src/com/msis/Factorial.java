package com.msis;
import java.util.*;
public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int fact;
		fact = sc.nextInt();
		
	}

}
