/**
 * 
 */
/**
 * @author MSIS
 *
 */
module My_Project {
	requires java.desktop;
}