package msis; 
import java.util.Random;

public class Producer implements Runnable {
    private Drop drop;

    public Producer(Drop drop) {
        this.drop = drop;
    }

    @Override
    public void run() {
        Random random = new Random();

        	int ran = random.nextInt(10);
        	while(ran != 9)
        	{
        		drop.put(ran);
        		 try {
                     Thread.sleep(random.nextInt(500));
                 } catch (InterruptedException e) {}
        		ran = random.nextInt(10);
        	}
           
        
        drop.put(ran);
    }
}

