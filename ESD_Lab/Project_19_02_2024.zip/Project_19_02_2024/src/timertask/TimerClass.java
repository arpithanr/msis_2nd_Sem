package timertask;

import java.util.Timer;
import java.util.TimerTask;

public class TimerClass{
 

	Timer timer;
	public TimerClass() {
		// TODO Auto-generated constructor stub
		timer = new Timer();
		TimerTask oneTimeTask = new OneTimeTask();
		timer.schedule(oneTimeTask, 8000);
		
		//Periodic task
		TimerTask periodicTask = new PeriodicTask();
		timer.schedule(periodicTask, 8000, 3000);

	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new TimerClass();	
		System.out.println("Tasks scheduled successfully....");

	}
	
	public static class OneTimeTask extends TimerTask{

		@Override
		public void run() {
			// TODO Auto-generated method stub
			System.out.println("One-time task executed......");
			
		}
	}
	
	public static class PeriodicTask extends TimerTask{
		private int count = 0 ;
		public PeriodicTask() {
	        count = 4;
	    }
	 
	    @Override
	    public void run() {
	        if (count > 0) {
	            System.out.println("Periodic task executed! Remaining executions: " + count);
	            count--;
	        } else {
	           cancel(); 
	            System.out.println("Periodic task completed!");
	        }
	    }
	}

}
