package timertask;

import java.util.Timer;
import java.util.TimerTask;
 
public class TaskTimer {
 
    private static final long ONE_TIME_DELAY = 8 * 1000L; // 8 seconds in milliseconds
    private static final long PERIODIC_DELAY = 3 * 1000L; // 3 seconds in milliseconds
    private static final int REPETITIONS = 4;
 
    public static void main(String[] args) {
        Timer timer = new Timer();
 
        // One-time task
        TimerTask oneTimeTask = new OneTimeTask();
        timer.schedule(oneTimeTask, ONE_TIME_DELAY);
 
        // Periodic task
        TimerTask periodicTask = new PeriodicTask();
        timer.scheduleAtFixedRate(periodicTask, 0, PERIODIC_DELAY);
 
        System.out.println("Tasks scheduled successfully.");
    }
 
    private static class OneTimeTask extends TimerTask {
        @Override
        public void run() {
            System.out.println("One-time task executed.");
            // Add your one-time task functionality here
        }
    }
 
    private static class PeriodicTask extends TimerTask {
        private int count = 0;
 
        @Override
        public void run() {
            System.out.println("Periodic task executed (" + (count + 1) + " of " + REPETITIONS + ").");
            // Add your periodic task functionality here
            count++;
            if (count >= REPETITIONS) {
                cancel();
            }
        }
    }
}
