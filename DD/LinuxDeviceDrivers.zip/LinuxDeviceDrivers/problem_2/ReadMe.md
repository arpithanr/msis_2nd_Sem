Write an ioctl command to sort the nth quantum of the first Sculldev in scull device(modify main.c)

```
make clean
make
sudo sh scull_unload
sudo sh scull_load
gcc use_semaphore.c
cat in.txt>/dev/scull0
cat /dev/scull0
./a.out
w
cat /dev/scull0
```
