Create a proc entry to change the quantum in each scull device.

```
make clean
make
sudo sh scull_unload
sudo sh scull_load
cat /proc/scullmem
```
