package msis;

@FunctionalInterface
interface If1 {
	boolean isOddEven(int n);
}

@FunctionalInterface
interface Fact{
//n is some natural number whose factorial is to be computed
	int fact(int n);
}

public class TestLambda{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		If1 isEven = (n) -> check(n);

		
		if (isEven.isOddEven(21)) {
			System.out.println("21 is even");
		}
		else {
			System.out.println("21 is odd");
		}
		
		Fact num = (n)->checkFact(n);
		System.out.println("fact of 5 is: " + num.fact(5));

	}
	
	public static boolean check(int n)
	{
		if((n%2) == 0)
			return true;
		else
			return false;
	}
	
	public static int checkFact(int n) {
		// TODO Auto-generated method stub
		int fact = 1;
		for(int i =1; i<=n; i++)
		{
			fact = fact * i;
		}
		return fact;
	}
}
