package msis;

public class ThreadDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Annonymous Inner class
//		Runnable r = new Runnable()
//		{
//
//			@Override
//			public void run() {
//				// TODO Auto-generated method stub
//				for(int i=0; i<4; i++)
//				{
//					System.out.println(i);
//					work();
//				}
//				
//			}
//			
//		};
		
		Runnable r1 = ()->work();
		Thread t = new Thread(r1);
		t.start();
 	}
	
	public static void work() {
		
		for(int i=0; i<4; i++)
		{
			System.out.println(i);
		}
		try {
			Thread.sleep(1000);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
