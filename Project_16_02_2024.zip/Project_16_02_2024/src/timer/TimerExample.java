package timer;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class TimerExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TimerTask task = new TaskHelper();
		Timer timer = new Timer(true);
		
		timer.scheduleAtFixedRate(task, new Date(), 2000);
		//timer.schedule(task, new Date(), 2000);
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		timer.cancel();		
	}
}
