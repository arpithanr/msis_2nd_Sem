package timer;
import java.util.Timer;
import java.util.TimerTask;

public class TimerDemo{

	public static void main(String args[]){
        TimerDemo.DelayTask task = new DelayTask();
        Timer timer = new Timer();
        /**
         * Use schedule or scheduletAtFixedrate and check the printed result
         */
      // timer.schedule(task, 0, 5000);
        timer.scheduleAtFixedRate(task, 0, 5000);
    }

    public static boolean stop = false;

    public static void delayOneSec(String status){
        try{
            System.out.print(status);
            Thread.sleep(1000);
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    static class DelayTask extends TimerTask{
        int count = 2;
        public static int track = 0;
        @Override
        public void run() {
            // TODO Auto-generated method stub
            stop = true;
            System.out.println("\ntask: " + (++track));
            for(int i = 0; i < count; i++){
                TimerDemo.delayOneSec("T");
            }
            if(count == 2){
                count = 6;
            }else{
                count = 2;
            }
            stop = false;
            new PrintW().start();
        }
    }

    static class PrintW extends Thread{
        @Override
        public void run(){
            while(!stop){
                TimerDemo.delayOneSec("W");
            }
        }

    }
}
