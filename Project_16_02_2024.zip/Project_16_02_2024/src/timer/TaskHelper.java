package timer;
import java.util.Date;
import java.util.TimerTask;

public class TaskHelper extends TimerTask {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Timer task started at:"+new Date());
	    completeTask();
	    System.out.println("Timer task finished at:"+new Date());

	}
	
	public void completeTask() {
		try {
            //assuming it takes 2 secs to complete the task
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
	}

}
