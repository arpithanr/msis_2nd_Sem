package timer;

import java.util.Timer;
import java.util.TimerTask;
class HelperTask extends TimerTask{

	public static int count=0;
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("timer count: " + ++count);
		if(count==4) {
			synchronized (TestTask.obj)
			{
				TestTask.obj.notify();
			}
		}
	}
	
}
public class TestTask {

	public static HelperTask obj;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		obj=new HelperTask();
		Timer timer =new Timer();
		timer.schedule(obj, 1000,500);
		
		synchronized(obj) {
			
			try {
				obj.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Cancel the timer object....");
		timer.cancel();
		
	}

}
