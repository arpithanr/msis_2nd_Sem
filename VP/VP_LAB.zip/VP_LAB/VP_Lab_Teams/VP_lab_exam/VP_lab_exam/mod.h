#include <systemc.h>

SC_MODULE(mod)
{
	sc_in<bool>clk,rst;
	sc_out<sc_uint<5>>counter;
	
	sc_uint<4>registervalue;
	
	void compute()
	{
		if(rst.read())
		{
			registervalue=0;
			counter.write(registervalue);
		}
		else{
			registervalue=(registervalue+1)%9;
			counter.write(registervalue);
		}
		
	
	}
		SC_CTOR(mod){
		
			SC_METHOD(compute);
			sensitive <<clk.pos()<<rst;
		}

};
